# @crashgalaxy/hud — Crash Galaxy branded slot HUD

One HUD for every Crash Galaxy slot: the bet/balance/win bar, spin button, autoplay picker, bet ladder, feature-buy sheet, burger menu, rules sheet and replay bar, as designed in `hud.fig` ("HUD Kit") and as shipped and Stake-approved in new_world_order. Games consume it as a Svelte 5 package and pass a typed `HudConfig`; nothing game-specific lives in the library.

## Quick start (web-sdk game)

```jsonc
// frontend/package.json
"dependencies": { "@crashgalaxy/hud": "github:realBiffTannen/crashgalaxy-hud#v1.0.1" }
// v1.0.1 IS NOT TAGGED YET. Until someone cuts and pushes it, pin the working copy instead:
//   "dependencies": { "@crashgalaxy/hud": "link:../../../crashgalaxy-hud" }
// from a web-sdk app directory. That is what GANJA FARM, the first adopter, ships on.
```
```bash
npm run sync && cd ~/code/web-sdk && pnpm install          # peers (svelte, state-shared) resolve from the workspace
cp node_modules/@crashgalaxy/hud/dist/assets/hud/*.svg frontend/static/assets/hud/
```
```svelte
<!-- frontend/src/routes/+layout.svelte -->
<script lang="ts">
	import '@crashgalaxy/hud/styles.css';          // tokens → hud → feature-buy → rules, fixed cascade
	import { CrashGalaxyHud } from '@crashgalaxy/hud';
	import { hudConfig } from '../hud.config';     // see docs/examples/hud.config.example.ts
</script>
<Game />
<CrashGalaxyHud config={hudConfig} />
```

Full recipe, config reference, fonts, strings, feature scenes: **[docs/INTEGRATION.md](docs/INTEGRATION.md)**.

## What is in the box

| Export | Purpose |
|---|---|
| `CrashGalaxyHud` | the host component: binds web-sdk `state-shared` to the kit, implements the Stake-review law once |
| `HudConfig`, `resolveConfig`, `deriveBetModeType` | typed game config + defaults + validation |
| `claimWin` / `releaseWin`, `setFeatureSpins` | feature scenes that own the WIN readout / print shots left |
| `createStrings`, `defaultStrings` | 62-key HUD copy table (std + social variants); override per game |
| `defaultMoney` | the review-proven money display law |
| `holdPressGate` / `isPressGateOpen`, `hudReserve`, `timeScaleFor`, `VOLUME_MAX_STEP` | seams a game must share with the host, not copy — see INTEGRATION §10 |
| `awaitWinBar` / `registerWinBar`, `createWinCountUp` | block a book-event handler until the WIN bar has finished counting |
| `@crashgalaxy/hud/styles.css`, `@crashgalaxy/hud/tokens.css` | kit CSS; design tokens generated from `hud.fig` |

## Design source of record

`hud.fig` (Figma "HUD Kit"). Sanctioned frames: `hud_flex_desktop`, `game_flex_feature-buy`, `change_base_bet_modal`, `modal_auto-spin`, `modal_replay`. Pages **not** to use: HUD Old, HUD Works, HUD References, Internal Only Canvas. Decoded frame trees: `docs/fig/`. Tokens: `pnpm tokens` regenerates `src/lib/tokens/` from the fig.

## History note — CANDY port (2026-09-11)

Before this push `origin/main` was `650cb85` ("Release 1.0.0"). Commits `5e7285b`, `5768c63`
and `7392920` on top of it fold in everything CANDY (candy_town) had carried as dist edits on
its vendored `94b07c8` — itself `650cb85` plus the ante chip token, built on the handoff
machine and never pushed — and ship Lilita One with the kit. The package build at `5768c63`
is byte-identical to CANDY's vendored dist. Itemised in `CHANGELOG.md` "Unreleased".

## Docs

- `docs/INTEGRATION.md` — adopting the package in a game (and migrating an older Xmas-lineage HUD)
- `docs/ARCHITECTURE.md` — seams, data flow, review-law inventory, fig → component map
- `docs/EXTRACTION_LEDGER.md` — every byte that differs from the new_world_order kit, with reasons
- `docs/PARITY.md` — screenshot + computed-style parity harness; baselines for new_world_order and duckhunters are recorded in `docs/parity/`
- `CHANGELOG.md`

## Development

```bash
pnpm install && pnpm build      # svelte-package → dist/ (committed)
pnpm test:unit                  # ledger (zero-drift), tokens, css literals, strings, money, config, host gates
pnpm check                      # svelte-check
pnpm tokens                     # regenerate tokens from hud.fig
pnpm parity:capture -- --driver nwo --out parity/nwo/<label>   # see docs/PARITY.md
```

Any change under `src/lib/components`, `src/lib/shims` or `src/lib/styles` must keep `tests/unit/extraction-ledger.test.mjs` green or add a ledger row.
